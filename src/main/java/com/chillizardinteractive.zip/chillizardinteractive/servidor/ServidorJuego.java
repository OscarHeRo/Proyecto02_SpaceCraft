package com.chillizardinteractive.servidor;

import com.chillizardinteractive.broker.MessageBroker;
import com.chillizardinteractive.controlador.GameController;
import com.chillizardinteractive.controlador.PlayerController;
import com.chillizardinteractive.modelo.gameState.GameContext;
import com.chillizardinteractive.modelo.player.Player;
import com.chillizardinteractive.vista.GameView;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class ServidorJuego {
    private static final int PUERTO = 8080;
    private List<PrintWriter> clientes = new ArrayList<>();
    private GameController gameController;
    private PlayerController playerController;
    private MessageBroker messageBroker;

    public static void main(String[] args) {
        new ServidorJuego().iniciarServidor();
    }

    public ServidorJuego() {
        Player player1 = new Player("Jugador1");
        Player player2 = new Player("Jugador2");
        GameView view = new GameView();
        GameContext context = new GameContext(player1, player2, view);
        this.gameController = new GameController(context);
        this.playerController = new PlayerController(context.getPlayers(), gameController, view);
        this.messageBroker = new MessageBroker(gameController, playerController);
    }

    public void iniciarServidor() {
        try (ServerSocket serverSocket = new ServerSocket(PUERTO)) {
            System.out.println("Servidor iniciado en el puerto " + PUERTO);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nuevo cliente conectado: " + clientSocket.getInetAddress());
                new Thread(new ManejadorCliente(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class ManejadorCliente implements Runnable {
        private Socket clientSocket;

        public ManejadorCliente(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
            ) {
                synchronized (clientes) {
                    clientes.add(out);
                }

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    System.out.println("Mensaje del cliente: " + inputLine);
                    messageBroker.procesarMensaje(inputLine, out);
                }
            } catch (IOException e) {
                System.out.println("Error en la conexión con el cliente: " + clientSocket.getInetAddress());
                e.printStackTrace();
            }
        }
    }
}
