package com.chillizardinteractive.controlador;

import com.chillizardinteractive.modelo.gameState.GameContext;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class GameController {
    private GameContext context;
    private ScheduledExecutorService scheduler;

    public GameController(GameContext context) {
        this.context = context;
        this.scheduler = Executors.newScheduledThreadPool(1);
    }

    public void procesarJugadorListo() {
        System.out.println("Jugador listo confirmado. Total de jugadores listos: " + context.getNumeroJugadoresListos());
        if (context.todosLosJugadoresListos()) {
            iniciarJuego();
        }
    }

    public void iniciarJuego() {
        System.out.println("Todos los jugadores están listos. Iniciando juego...");
        context.iniciarJuego();
        iniciarTurno();
    }

    public void lanzarMoneda() {
        System.out.println("Lanzando moneda para determinar el jugador inicial...");
        context.lanzarMoneda();
    }

    public void iniciarTurno() {
        System.out.println("Iniciando turno del jugador: " + context.getCurrentPlayer().getName());
        context.iniciarTurno();
        startTurnTimer();
    }

    private void startTurnTimer() {
        System.out.println("Iniciando temporizador de turno (60 segundos)...");
        scheduler.schedule(() -> {
            System.out.println("Tiempo de turno agotado. Terminando turno automáticamente...");
            terminarTurno();
        }, 60, TimeUnit.SECONDS);
    }

    public void terminarTurno() {
        System.out.println("Turno finalizado.");
        context.terminarTurno();
        iniciarTurno();
    }

    // Método añadido para finalizar el juego
    public void finalizarJuego() {
        System.out.println("El juego ha terminado.");
        scheduler.shutdown();
    }
}
