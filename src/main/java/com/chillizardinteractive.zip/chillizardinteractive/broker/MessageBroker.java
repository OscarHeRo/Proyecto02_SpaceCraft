package com.chillizardinteractive.broker;

import com.chillizardinteractive.controlador.GameController;
import com.chillizardinteractive.controlador.PlayerController;
import com.chillizardinteractive.modelo.hunter.Hunter;

import java.io.PrintWriter;

public class MessageBroker {
    private GameController gameController;
    private PlayerController playerController;

    public MessageBroker(GameController gameController, PlayerController playerController) {
        this.gameController = gameController;
        this.playerController = playerController;
    }

        public void procesarHunter(String nombreJugador, int hunterNumber, PrintWriter out) {
        try {
            Hunter hunter = Hunter.getHunterByNumber(hunterNumber);
            System.out.println("Asignando Hunter " + hunter.getName() + " al jugador " + nombreJugador);
            out.println("Hunter asignado: " + hunter.getName());
        } catch (IllegalArgumentException e) {
            System.out.println("Número de Hunter inválido: " + hunterNumber);
            out.println("Número de Hunter inválido. Seleccione un número del 1 al 6.");
        }
    }

    public void procesarMensaje(String mensaje, PrintWriter out) {
        System.out.println("Procesando mensaje: " + mensaje); // Mensaje de depuración
        String[] partes = mensaje.split(":");
        String accion = partes[0];
        try {
            switch (accion) {
                case "nombre":
                    playerController.procesarNombre(partes[1], out);
                    break;

                case "hunter":
                    int hunterNumber = Integer.parseInt(partes[1]);
                    playerController.procesarHunter(hunterNumber, out);
                    break;

                case "listo":
                    System.out.println("Jugador listo, intentando iniciar el juego...");
                    gameController.procesarJugadorListo();
                    break;

                case "movimiento":
                    gameController.procesarMovimiento(partes[1], partes[2]);
                    break;

                default:
                    System.out.println("Acción no reconocida: " + accion);
                    out.println("Acción no válida.");
                    break;
            }
        } catch (Exception e) {
            System.out.println("Error procesando mensaje: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
